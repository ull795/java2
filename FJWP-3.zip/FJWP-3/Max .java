package p4;
import java.util.*;
public class Max {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a,b,MAX=0;
		System.out.print("enter the value of a:");
		a = sc.nextInt();
		System.out.print("enter the value of b:");
		b = sc.nextInt();
		if(a>b)
		{
			System.out.println("Maximum value is a that is " +a);
		}
		else
		{
			System.out.println("Maximum value is b that is " +b);
		}
		

	}

}
