package p4;
import java.util.*;
public class PositiveNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num;
		System.out.print("enter the number:");
		num = sc.nextInt();
		if(num<1)
		{
			System.out.print("Entered number is negative that is "+ num);
		}
		else
		{
			System.out.print("Entered number is positive that is "+ num);
		}
	}

}
