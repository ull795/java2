package p4;

public class UseridPassword {

    public static void main(String[] args) {
        String userId = "admin";
        String password = "admine@123";
        
        
        if(userId=="admin") 
        {
            
            if(password=="admine@123") 
            {
                System.out.println("Login successful");
            } 
            else 
            {
                System.out.println("Login unsuccessful");
            }
        }
        else 
        {
            System.out.println("Invalid User ID");
        }
    }
}
