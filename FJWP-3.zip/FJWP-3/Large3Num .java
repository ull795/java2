package p4;
import java.util.*;
public class Large3Num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a,b,c,MAX=0;
		System.out.print("enter the value of a:");
		a = sc.nextInt();
		System.out.print("enter the value of b:");
		b = sc.nextInt();
		System.out.print("enter the value of c:");
		c = sc.nextInt();
		if(a>b)
		{
			System.out.println("Maximum value is a that is " +a);
		}
		else if(c>b)
		{
			System.out.println("Maximum value is c that is " +c);
		}
		else
		{
			System.out.println("Maximum value is b that is " +b);
		}
	}

}
